document.getElementById("btn").addEventListener("click",function(){
    alert("내부방식 클릭!")
})
