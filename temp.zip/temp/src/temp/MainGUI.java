package temp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import java.awt.Color;
import javax.swing.JLayeredPane;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.ButtonGroup;

public class MainGUI {

	private JFrame frame;
	private JTextField textField;
	private JTextField textField_1;
	private final ButtonGroup buttonGroup = new ButtonGroup();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainGUI window = new MainGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(70, 130, 180));
		frame.getContentPane().setForeground(new Color(70, 130, 180));
		frame.setBounds(100, 100, 800, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton_1_1 = new JButton("\uB85C\uADF8\uC778");
		btnNewButton_1_1.setFont(new Font("��������", Font.PLAIN, 12));
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("\uAD50\uC0AC");
		buttonGroup.add(rdbtnNewRadioButton_1);
		rdbtnNewRadioButton_1.setFont(new Font("��������", Font.PLAIN, 12));
		rdbtnNewRadioButton_1.setBackground(Color.WHITE);
		rdbtnNewRadioButton_1.setBounds(225, 269, 63, 23);
		frame.getContentPane().add(rdbtnNewRadioButton_1);
		btnNewButton_1_1.setBounds(68, 312, 100, 30);
		frame.getContentPane().add(btnNewButton_1_1);
		
		textField = new JTextField();
		textField.setBounds(143, 183, 145, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("\uD559\uC0DD");
		buttonGroup.add(rdbtnNewRadioButton);
		rdbtnNewRadioButton.setFont(new Font("��������", Font.PLAIN, 12));
		rdbtnNewRadioButton.setBackground(Color.WHITE);
		rdbtnNewRadioButton.setBounds(144, 269, 63, 23);
		frame.getContentPane().add(rdbtnNewRadioButton);
		
		JLabel lblNewLabel = new JLabel("\uC544\uC774\uB514");
		lblNewLabel.setFont(new Font("��������", Font.PLAIN, 15));
		lblNewLabel.setBounds(74, 188, 57, 15);
		frame.getContentPane().add(lblNewLabel);
		lblNewLabel.setBackground(Color.WHITE);
		
		JLabel lblNewLabel_3 = new JLabel("\uD559\uAD50 \uC131\uC801 \uAD00\uB9AC \uD504\uB85C\uADF8\uB7A8");
		lblNewLabel_3.setFont(new Font("����������_ac Bold", Font.PLAIN, 23));
		lblNewLabel_3.setBounds(68, 72, 291, 48);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("\uB85C\uACE0");
		lblNewLabel_4.setBounds(297, 78, 39, 43);
		frame.getContentPane().add(lblNewLabel_4);
		
		textField_1 = new JTextField();
		textField_1.setColumns(10);
		textField_1.setBounds(143, 226, 145, 26);
		frame.getContentPane().add(textField_1);
		
		JLabel lblPw = new JLabel("\uBE44\uBC00\uBC88\uD638");
		lblPw.setFont(new Font("��������", Font.PLAIN, 15));
		lblPw.setBackground(Color.WHITE);
		lblPw.setBounds(74, 231, 57, 15);
		frame.getContentPane().add(lblPw);
		
		JButton btnNewButton_1_1_1 = new JButton("\uD68C\uC6D0\uAC00\uC785");
		btnNewButton_1_1_1.setFont(new Font("��������", Font.PLAIN, 12));
		btnNewButton_1_1_1.setBounds(188, 312, 100, 30);
		frame.getContentPane().add(btnNewButton_1_1_1);
		
		JLabel lblNewLabel_4_1 = new JLabel("\uC774\uBBF8\uC9C0");
		lblNewLabel_4_1.setBounds(476, 84, 264, 271);
		frame.getContentPane().add(lblNewLabel_4_1);
		
		JLabel lbl_background = new JLabel("");
		lbl_background.setHorizontalAlignment(SwingConstants.LEFT);
		lbl_background.setVerticalAlignment(SwingConstants.TOP);
		lbl_background.setFont(new Font("�������� ExtraBold", Font.PLAIN, 12));
		lbl_background.setOpaque(true);
		lbl_background.setBackground(new Color(255, 255, 255));
		lbl_background.setBounds(22, 25, 739, 411);
		frame.getContentPane().add(lbl_background);
	}
}
