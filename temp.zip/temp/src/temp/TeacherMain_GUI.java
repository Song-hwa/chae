package temp;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class TeacherMain_GUI {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TeacherMain_GUI window = new TeacherMain_GUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public TeacherMain_GUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 800, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("\uD68C\uC6D0\uC815\uBCF4\uC218\uC815");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(511, 44, 105, 23);
		frame.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel_1 = new JLabel("\uACF5\uC9C0\uC0AC\uD56D");
		lblNewLabel_1.setBounds(281, 90, 444, 275);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnMy = new JButton("\uC131\uC801\uC870\uD68C");
		btnMy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnMy.setBounds(54, 143, 179, 169);
		frame.getContentPane().add(btnMy);
		
		JButton btnNewButton_2 = new JButton("\uB4A4\uB85C(\uC774\uBBF8\uC9C0)");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2.setBounds(54, 44, 114, 23);
		frame.getContentPane().add(btnNewButton_2);
		
		JButton btnNewButton_2_1 = new JButton("\uB85C\uADF8\uC544\uC6C3");
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton_2_1.setBounds(628, 44, 97, 23);
		frame.getContentPane().add(btnNewButton_2_1);
		
		JLabel lbl_background = new JLabel("");
		lbl_background.setHorizontalAlignment(SwingConstants.LEFT);
		lbl_background.setVerticalAlignment(SwingConstants.TOP);
		lbl_background.setFont(new Font("�������� ExtraBold", Font.PLAIN, 12));
		lbl_background.setOpaque(true);
		lbl_background.setBackground(new Color(255, 255, 255));
		lbl_background.setBounds(22, 25, 739, 411);
		frame.getContentPane().add(lbl_background);
	}

}
