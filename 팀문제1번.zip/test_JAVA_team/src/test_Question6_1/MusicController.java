package test_Question6_1;

import java.util.ArrayList;

public class MusicController {
	ArrayList<MusicVO> list = new ArrayList<>();
	
	public void addList(String title, String singer, int playTime) {
		list.add(new MusicVO(title, singer, playTime));
	}
}
