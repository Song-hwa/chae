package test;

import java.util.Scanner;

public class q4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while(true) {
  
		System.out.print("id:");
		String id = sc.next();

		System.out.print("pw:");
		String pw = sc.next();
		

		if(id.equals("dldmsql") && pw.equals("1214")) {
		
			System.out.println("dldmsql�� ȯ���մϴ�!");
			break;
		}else {

			
	
			System.out.print("�ٽ�Ȯ���ϼ���!");
			String re = sc.next();
			
			
			if(id.equals("dldmsql") && pw.equals("1214")) {
				
				System.out.println("dldmsql�� ȯ���մϴ�!");
				break;
			}
			
		}
		}
	}
}

			
