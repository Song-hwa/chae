package test;

import java.util.Scanner;

public class q3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("�����Է�>>");
		
		int age = sc.nextInt();
		
		if(age >= 40) {
		   System.out.println("�ʳ��Դϴ�.");
		
		
		if(age >= 41) {
				
				System.out.println("�߳��Դϴ�.");
		}
		if(age >= 61) {	
					System.out.println("����Դϴ�.");
			

	}

}
}
}

 
