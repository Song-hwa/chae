package day05;

public class ex06�޼ҵ� {

	public static void main(String[] args) {
		int[] array = { 1, 3, 4, 8, 7, 9, 10 };
		arrayToString(array);
	}

	public static void arrayToString(int[] arr) {
		for (int i = 0; i < arr.length; i++) {
			System.out.print(arr[i] + " ");
		}
	}

}
