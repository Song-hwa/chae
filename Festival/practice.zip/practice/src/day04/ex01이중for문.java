package day04;

public class ex01����for�� {

	public static void main(String[] args) {

		for (int i = 0; i < 5; i++) {
			for (int j = 5; i < j; j--) {
				System.out.print("*");
			}
			System.out.println();
		}
		
	}

}
