package day06;

public class Qus3 {

	public static void main(String[] args) {
		
		
	}

}
