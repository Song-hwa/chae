public class Q25 {

	public static void main(String[] args) {
		�𸣰ڴ�
				
	}

}
