package festival;

public class SCORE {

	public static void main(String[] args) {
		
		String score = "A,A,B,C,D,A,C,D,D,D,F";
		String[] str = score.split(",");
		
		String[] hak = {"A", "B", "C","D","E","F"};
		
		int[] cnt = new int[6];
		for(int i =0; i<hak.length; i++) {
			int num =0;
			for(int j=0; j<str.length; j++) {
				if(hak[i].equals(str[j])) {
					num++;
				}
			}
			cnt[i]=num;
		}
for(int i =0; i<hak.length; i++) {
	if(cnt[i]>0)
		System.out.println(hak[i]+":"+cnt[i]+"��");
}
	}

}
