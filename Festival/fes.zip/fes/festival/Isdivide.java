package festival;

import java.util.Scanner;

public class Isdivide {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner (System.in);
		System.out.print("�����Է�>>");
		int num1 = sc.nextInt();
		System.out.print("�����Է�>>");
		int num2  = sc.nextInt();
		
		
		 
	      boolean result = isDivide(num1, num2);
	      System.out.println("��� : "+result);
	   
   }
	  public static boolean isDivide(int num1, int num2) {
	      if (num1 % num2 == 0) {
	         return true;
	      } else {
	         return false;
	      }
	   }

}
