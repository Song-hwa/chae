package festival;

public class ABC {

	public static void main(String[] args) {
		
		for(int i = 65; i<=90; i++) {
			System.out.print((char)i + "  ");
			
		}
    System.out.println();
    //10���� ���ڸ� 16������ ��ȯ
    for (int i =65; i<=90; i++) {
    	System.out.print("0x"+ Integer.toHexString(i)+"  ");
    }
	}

}
