package festival;

public class METHOD {
	public static void main(String[] args) {
		
		cal(42,3,'/');
	}
	public static void cal(int num1, int num2, char op) {
 
	
		
		if(op==43) {
			System.out.println(num1+num2);
			
	}else if(op==45) {
		System.out.println(num1-num2);
		
	}else if (op==42) {
		System.out.println(num1*num2);
		
	}else {
		System.out.println(num1/num2);
	}

	}

}
