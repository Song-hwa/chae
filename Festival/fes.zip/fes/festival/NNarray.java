package festival;

import java.util.Scanner;

public class NNarray {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("������ �Է��ϼ���:");
		int n = sc.nextInt();
		
		int[][] iArr = new int[n][n];
		
		int num = 1;
		for(int i =0; i<iArr.length; i++) {
			for(int j=0; j<iArr[i].length; j++) {
				iArr[i][j]=num;
				num++;
				
			}
		}

		for(int i=0; i<iArr.length; i++) {
			for(int j=0; j<iArr[i].length; j++) {
				
				System.out.print((iArr[i][j])+"\t");
			}
		System.out.println();
	}
	}
}
