package festival;

import java.util.Scanner;

public class Work {

	public static void main(String[] args) {
	
		Scanner scan = new Scanner(System.in);
		
		System.out.print("���ѽð��� �Է��ϼ���");
		int hour = scan.nextInt();
		
		int m =5000;
		int pay = 0;
		
		if (hour>8) {
			int over =hour -8;
			pay = (m*8)+(int)(over*m*1.5);
			
		}else {
			pay = m*hour;
		}
		System.out.println("�� �ӱ���"+pay+"�� �Դϴ�");
		
	}

}
