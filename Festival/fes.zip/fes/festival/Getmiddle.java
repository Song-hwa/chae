package festival;

public class Getmiddle {

	public static void main(String[] args) {
		
		System.out.println(getMiddle("power"));
		System.out.println(getMiddle("test"));
		
	}
    private static String getMiddle(String word) {
    	int length = word.length();
    	int index = length/2;
    	String result = (length%2==0)? word.substring(index-1, index+1): word.substring(index, index+1);
    	return result;
    }
}
